/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author rafael
 */
public class Avaliador {
    private int idAvaliador;
    private static int cont;
    private String nome;
    //private boolean ativo;
    
    public Avaliador (String nome){        
        this.nome = nome;
        this.idAvaliador = cont + 1;
        cont +=1;
        
    }
    public String toString(){
        return "Nome Avaliador: "+ this.nome;
    }
    
}
