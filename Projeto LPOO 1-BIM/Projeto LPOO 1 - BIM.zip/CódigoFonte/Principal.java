/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author rafael
 */
public class Principal {

    public static void main(String[] arg) {
        int[] op = new int[10];
        boolean verf = false;
        ArrayList<Avaliador> av = new ArrayList();
        ArrayList<OndeComi> ha = new ArrayList<OndeComi>();
        ArrayList<OndeComi> jp = new ArrayList<OndeComi>();
        ArrayList<OndeComi> br = new ArrayList<OndeComi>();

        do {

            try {
                // Menu Principal
                op[1] = Integer.parseInt(JOptionPane.showInputDialog("Entre com a opção desejada:"
                        + "\n1-Cadastrar Avaliador"
                        + "\n2-Categorias"
                        + "\n3-Ranking"
                        + "\n4-Sair"));
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Digite apenas numeros");

            }
            switch (op[1]) {

                // Cadastro do Avaliador
                case 1:

                    Avaliador avaliador = new Avaliador(JOptionPane.showInputDialog("Entre como o nome"));
                    av.add(avaliador);
                    JOptionPane.showMessageDialog(null, "Cadastrado com Sucesso");
                    break;


                //Categrias     
                case 2:

                    try {
                        op[2] = Integer.parseInt(JOptionPane.showInputDialog("Entre com a opção desejada:"
                                + "\n1-Hamburguerias"
                                + "\n2-Japonês"
                                + "\n3-Bar"
                                + "\n4-Voltar ao Menu Anterior"));
                        verf = false;

                    } catch (NumberFormatException e) {
                        JOptionPane.showMessageDialog(null, "Digite apenas numeros");
                        verf = true;
                    }

                    switch (op[2]) {

                        // Hamburgeuria ==>
                        case 1:
                            // Menu Hamburgueria 
                            do {
                                try {
                                    op[3] = Integer.parseInt(JOptionPane.showInputDialog("Entre com a opção desejada:"
                                            + "\n1-Cadastrar Hamburguerias"
                                            + "\n2-Consultar Hamburgueria"
                                            + "\n3-Excluir cadastro Hamburgueria"
                                            + "\n4-Alterar cadastro"
                                            + "\n5-Avaliar / Alterar Avaliação"
                                            + "\n6-Voltar ao menu anterior"));
                                    verf = false;
                                } catch (NumberFormatException e) {
                                    JOptionPane.showMessageDialog(null, "Digite apenas numeros");
                                    verf = true;
                                }
                                switch (op[3]) {

                                    //Cadastrar Hamburguerias
                                    case 1:
                                        OndeComi x = new Hamburgueria();
                                        
                                        ha.add(x.criarLocal());
                                        break;

                                    //Consultar Hamburguerias
                                    case 2:
                                        String cons = JOptionPane.showInputDialog("Digite o nome da Hamburgueria desejada:");
                                        for (int i = 0; i < ha.size(); i++) {
                                            if (cons.equals(ha.get(i).getNome())) {
                                                JOptionPane.showMessageDialog(null, av.get(0).toString() + "\n" + ha.get(i).selecoinarLocal());
                                            }
                                        }
                                        break;

                                    // Excluir cadastro estabelecimento
                                    case 3:
                                        cons = JOptionPane.showInputDialog("Digite o nome da Hamburgueria que deseja excluir:");
                                        for (int i = 0; i < ha.size(); i++) {
                                            if (cons.equals(ha.get(i).getNome())) {                                       
                                                ha.remove(i);
                                                JOptionPane.showMessageDialog(null, "Estabelecimetno excluido com sucesso !");
                                            }
                                        }
                                        break;

                                    // Alterar Cadastro
                                    case 4:
                                        cons = JOptionPane.showInputDialog("Digite o nome da Hamburgueria desejada:");
                                        for (int i = 0; i < ha.size(); i++) {
                                            if (cons.equals(ha.get(i).getNome())) {
                                                JOptionPane.showMessageDialog(null, av.get(0).toString() + "\n" + ha.get(i).selecoinarLocal());
                                                ha.get(i).alterarLocal();
                                                JOptionPane.showMessageDialog(null, av.get(0).toString() + "\n" + ha.get(i).selecoinarLocal());
                                            }
                                        }
                                        break;

                                    // Avaliar Hamburgueria
                                    case 5:
                                        cons = JOptionPane.showInputDialog("Digite o nome da Hamburgueria desejada:");
                                        for (int i = 0; i < ha.size(); i++) {
                                            if (cons.equals(ha.get(i).getNome())) {
                                                JOptionPane.showMessageDialog(null, av.get(0).toString() + "\n" + ha.get(i).selecoinarLocal());
                                                ha.get(i).avaliarItens();
                                                JOptionPane.showMessageDialog(null, av.get(0).toString() + "\n" + ha.get(i).selecoinarLocal());
                                            }
                                        }

                                        break;
                                }
                            } while (op[3] != 6);
                            break;


                        // Japonnes 
                        case 2:

                            // Menu Japonês 
                            do {
                                try {
                                    op[4] = Integer.parseInt(JOptionPane.showInputDialog("Entre com a opção desejada:"
                                            + "\n1-Cadastrar Restaturante Japonês"
                                            + "\n2-Consultar Restaurantes Japonês"
                                            + "\n3-Excluir cadastro Restaurante"
                                            + "\n4-Alterar cadastro"
                                            + "\n5-Avaliar / Alterar Avaliação"
                                            + "\n6-Voltar ao menu anterior"));
                                    verf = false;
                                } catch (NumberFormatException e) {
                                    JOptionPane.showMessageDialog(null, "Digite apenas numeros");
                                    verf = true;
                                }
                                switch (op[4]) {

                                    //Cadastrar Restaurantes Japonês
                                    case 1:
                                        OndeComi j = new Japones();
                                        jp.add(j.criarLocal());
                                        break;

                                    //Consultar Restaurante Japonês 
                                    case 2:
                                        String cons = JOptionPane.showInputDialog("Digite o nome do Restaurante desejado:");
                                        for (int i = 0; i < jp.size(); i++) {
                                            if (cons.equals(jp.get(i).getNome())) {
                                                JOptionPane.showMessageDialog(null, av.get(0).toString() + "\n" + jp.get(i).selecoinarLocal());
                                            }
                                        }
                                        break;

                                    // Excluir cadastro estabelecimento
                                    case 3:
                                        cons = JOptionPane.showInputDialog("Digite o nome do Restaurante que deseja excluir:");
                                        for (int i = 0; i < jp.size(); i++) {
                                            if (cons.equals(jp.get(i).getNome())) {
                                                jp.remove(i);
                                                JOptionPane.showMessageDialog(null, "Estabelecimetno excluido com sucesso !");
                                            }
                                        }
                                        break;
                                    //Alterar cadastro
                                    case 4:
                                        cons = JOptionPane.showInputDialog("Digite o nome do Restaurante desejado:");
                                        for (int i = 0; i < jp.size(); i++) {
                                            if (cons.equals(jp.get(i).getNome())) {
                                                JOptionPane.showMessageDialog(null, av.get(0).toString() + "\n" + jp.get(i).selecoinarLocal());
                                                jp.get(i).alterarLocal();
                                                JOptionPane.showMessageDialog(null, av.get(0).toString() + "\n" + jp.get(i).selecoinarLocal());
                                            }
                                        }
                                        break;

                                    // Avaliar / Alterar avaliação    
                                    case 5:
                                        cons = JOptionPane.showInputDialog("Digite o nome do Restaurante desejado:");
                                        for (int i = 0; i < jp.size(); i++) {
                                            if (cons.equals(jp.get(i).getNome())) {
                                                JOptionPane.showMessageDialog(null, av.get(0).toString() + "\n" + jp.get(i).selecoinarLocal());
                                                jp.get(i).avaliarItens();
                                                JOptionPane.showMessageDialog(null, av.get(0).toString() + "\n" + jp.get(i).selecoinarLocal());
                                            }
                                        }
                                        break;
                                }
                            } while (op[4] != 6);
                            break;


                        //Bar
                        case 3:

                            // Menu Bar
                            do {
                                try {
                                    op[5] = Integer.parseInt(JOptionPane.showInputDialog("Entre com a opção desejada:"
                                            + "\n1-Cadastrar Bar"
                                            + "\n2-Consultar Bar"
                                            + "\n3-Excluir Bar"
                                            + "\n4-Alterar cadastro"
                                            + "\n5-Avaliar / Alterar Avaliação"
                                            + "\n6-Voltar ao menu anterior"));
                                    verf = false;
                                } catch (NumberFormatException e) {
                                    JOptionPane.showMessageDialog(null, "Digite apenas numeros");
                                    verf = true;
                                }
                                switch (op[5]) {

                                    //Cadastrar Bar
                                    case 1:
                                        OndeComi b = new Bar();
                                        br.add(b.criarLocal());
                                        break;

                                    //Consultar Bar
                                    case 2:
                                        String cons = JOptionPane.showInputDialog("Digite o nome do Bar desejado:");
                                        for (int i = 0; i < br.size(); i++) {
                                            if (cons.equals(br.get(i).getNome())) {
                                                JOptionPane.showMessageDialog(null, av.get(0).toString() + "\n" + br.get(i).selecoinarLocal());
                                            }
                                        }
                                        break;

                                    // Excluir cadastro estabelecimento
                                    case 3:
                                        cons = JOptionPane.showInputDialog("Digite o nome do Bar que deseja excluir:");
                                        for (int i = 0; i < br.size(); i++) {
                                            if (cons.equals(br.get(i).getNome())) {
                                                br.remove(i);
                                                JOptionPane.showMessageDialog(null, "Estabelecimetno excluido com sucesso !");
                                            }
                                        }
                                        break;

                                    // Alterar cadastro
                                    case 4:
                                        cons = JOptionPane.showInputDialog("Digite o nome do Bar desejado:");
                                        for (int i = 0; i < br.size(); i++) {
                                            if (cons.equals(br.get(i).getNome())) {
                                                JOptionPane.showMessageDialog(null, av.get(0).toString() + "\n" + br.get(i).selecoinarLocal());
                                                br.get(i).alterarLocal();
                                                JOptionPane.showMessageDialog(null, av.get(0).toString() + "\n" + br.get(i).selecoinarLocal());
                                            }
                                        }
                                        break;
                                    case 5:
                                        cons = JOptionPane.showInputDialog("Digite o nome do Bar desejado:");
                                        for (int i = 0; i < br.size(); i++) {
                                            if (cons.equals(br.get(i).getNome())) {
                                                JOptionPane.showMessageDialog(null, av.get(0).toString() + "\n" + br.get(i).selecoinarLocal());
                                                br.get(i).avaliarItens();
                                                JOptionPane.showMessageDialog(null, av.get(0).toString() + "\n" + br.get(i).selecoinarLocal());
                                            }
                                        }
                                        break;
                                }
                            } while (op[5] != 6);
                            break;
                    }
                    break;


                //Ranking    
                case 3:
                    break;

            }


        } while (op[1] != 4);
    }
}
