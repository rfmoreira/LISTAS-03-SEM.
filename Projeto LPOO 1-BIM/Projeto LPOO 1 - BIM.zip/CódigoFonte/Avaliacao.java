/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author rafael
 */
public interface Avaliacao {
    
    public double alteraAvalicao();
    public String avaliarItens();
    
}
