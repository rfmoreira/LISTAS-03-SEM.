/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author rafael
 */
public class Ranking {
    private double geral;
    private double itens;
    private OndeComi itensAvaliados;
    private Avaliador avaliador;
    
    public void avaliacaoGeral(){
        
    }
    
    public void avaliacaoPorCategoria(){
        
    }
}
