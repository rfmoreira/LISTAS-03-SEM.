/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import javax.swing.JOptionPane;

/**
 *
 * @author rafael
 */
public class Bar extends OndeComi implements Avaliacao {

    private double cerveja;
    
    public Bar() {
    }

    public Bar(String nome, String endereco, double preco) {
        super(nome, endereco, preco);
    }

    
    
    
    @Override
    public OndeComi criarLocal() {
        OndeComi br = null;
        String nome = JOptionPane.showInputDialog("Nome do Estabeecimento");
        String end = JOptionPane.showInputDialog("Digite o endereço do Estabelecimento");
        Double preco = Double.parseDouble(JOptionPane.showInputDialog(null, "Entre com o preço medio do estabelecimento"));
        Double cerveja  = Double.parseDouble(JOptionPane.showInputDialog(null, "Digite sua nota para a qualidade da cerveja"));
        
        br = new Japones(nome, end, preco, cerveja);
        return br;
    
    }

    @Override
    public void deletarLocal() {
    }

    @Override
    public void alterarLocal() {
        int op = 0;
        boolean verf;
        do {
            try {
                op = Integer.parseInt(JOptionPane.showInputDialog("Entre com a opção desejada:"
                        + "\n1-Alterar nome"
                        + "\n2-Alterar endereço"
                        + "\n3-Alterar preço medio"
                        + "\n4-Alterar nota da cerveja"
                        + "\n5-Sair"));
                verf = false;
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Digite apenas numeros");
                verf = true;
            }
            switch (op) {
                case 1:
                    setNome(JOptionPane.showInputDialog("Nome do estabelecimento"));
                    break;
                case 2:
                    setEndereco(JOptionPane.showInputDialog("Enedeço do estabelecimento"));
                    break;
                case 3:
                    setPreco(Double.parseDouble(JOptionPane.showInputDialog(null, "Entre com o preço medio do estabelecimento")));
                    break;
                case 4:
                    setCerveja(Double.parseDouble(JOptionPane.showInputDialog(null, "Digite sua nota para a Cerveja")));
                    break;
            }

        } while (op != 5);
    }

    @Override
    public String selecoinarLocal() {
                return "Nome estabelecimento: "+nome+
                "\nCódigo estabelecimento: "+this.idOndeComi+
                "\nEndereço: "+ endereco+
                "\nPreço Medio: "+ this.preco+
                "\nAvaliação da Cerveja: "+ this.cerveja
                + "\nNota Ambiente: " + this.ambiente
                + "\nNota Atendimento: " + this.atendimento
                + "\nNota Geral: " + this.notaGeral;
    }

    @Override
    public double alteraAvalicao() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String avaliarItens() {
        setAmbiente(Double.parseDouble(JOptionPane.showInputDialog("Nota para o ambiente: ")));
        setAtendimento(Double.parseDouble(JOptionPane.showInputDialog("Nota para o atendimento: ")));
        setNotaGeral(Double.parseDouble(JOptionPane.showInputDialog("Nota Geral: ")));
        return "Sucesso";
    
    }

    public double getCerveja() {
        return cerveja;
    }

    public void setCerveja(double cerveja) {
        this.cerveja = cerveja;
    }
    
    public int getIdOndeComi() {
        return idOndeComi;
    }

    public void setIdOndeComi(int idOndeComi) {
        this.idOndeComi = idOndeComi;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public double getPreco() {
        return preco;
    }

    public void setPreco(double preco) {
        this.preco = preco;
    }

    public double getAmbiente() {
        return ambiente;
    }

    public void setAmbiente(double ambiente) {
        this.ambiente = ambiente;
    }

    public double getAtendimento() {
        return atendimento;
    }

    public void setAtendimento(double atendimento) {
        this.atendimento = atendimento;
    }

    public double getNotaGeral() {
        return notaGeral;
    }

    public void setNotaGeral(double notaGeral) {
        this.notaGeral = notaGeral;
    }

    public double getNotaItens() {
        return notaItens;
    }

    public void setNotaItens(double notaItens) {
        this.notaItens = notaItens;
    }
    
}
