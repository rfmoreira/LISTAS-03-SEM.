/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author rafael
 */
public abstract class OndeComi implements Avaliacao{
     protected static int control;
     protected int idOndeComi;
     protected String nome , endereco;
     protected double preco, ambiente,atendimento,notaGeral,notaItens;

    public OndeComi() {
    }

     
    
     public OndeComi(String nome, String endereco, double preco) {        
        this.idOndeComi = control + 1;
        control += 1;
        this.nome = nome;
        this.endereco = endereco;
        this.preco = preco;
    }

    
     
     
    
     public abstract OndeComi criarLocal();
     public abstract void deletarLocal();
     public abstract void alterarLocal();
     public abstract String selecoinarLocal();    

    public static int getControl() {
        return control;
    }

    public static void setControl(int control) {
        OndeComi.control = control;
    }

    public int getIdOndeComi() {
        return idOndeComi;
    }

    public void setIdOndeComi(int idOndeComi) {
        this.idOndeComi = idOndeComi;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public double getPreco() {
        return preco;
    }

    public void setPreco(double preco) {
        this.preco = preco;
    }

    public double getAmbiente() {
        return ambiente;
    }

    public void setAmbiente(double ambiente) {
        this.ambiente = ambiente;
    }

    public double getAtendimento() {
        return atendimento;
    }

    public void setAtendimento(double atendimento) {
        this.atendimento = atendimento;
    }

    public double getNotaGeral() {
        return notaGeral;
    }

    public void setNotaGeral(double notaGeral) {
        this.notaGeral = notaGeral;
    }

    public double getNotaItens() {
        return notaItens;
    }

    public void setNotaItens(double notaItens) {
        this.notaItens = notaItens;
    }
     
     
}
